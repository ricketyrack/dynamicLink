//>>built
define("dijit/nls/it/loading",({loadingState:"Caricamento in corso...",errorState:"Si è verificato un errore"}));
