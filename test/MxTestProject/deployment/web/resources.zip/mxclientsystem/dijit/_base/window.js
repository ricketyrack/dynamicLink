//>>built
define("dijit/_base/window",["dojo/window","../main"],function(_1,_2){
_2.getDocumentWindow=function(_3){
return _1.get(_3);
};
});
